🧩 Cheat Sheet (Shortcut Key)

MOD = key Super/Windows

| Key        | Action                      |
|-----------|-----------------------------|
| MOD + f   | Launch Firefox              |
| MOD + m   | Launch Menu                 |
| MOD + a/b/c/d  | URxvt (urxvt theme)    |
| MOD + e   | Launch Caja                 |
| MOD + n   | dmenu                       |
| MOD + w   | Kill Apps                   |
| MOD + v   | Launch Virtualbox           |
| MOD + 1..4 | Workspace 1–4              |
| MOD + Tab  | Switch Layout              |
