from .utils import SingleLineMarquee, Search, load_banners_from_folder, get_random_banner,is_terminal_environment
from rich.console import Console
console = Console()
