#!/bin/bash

network &
#dmenu_run &
feh --bg-fill /home/leakos/Downloads/1.jpg &
#xmenus &
#xfce4-panel --disable-wm-check &
#dmenu_run -b -sb grey -sf black -nb '#0f101a' -p 'BlackarchMenu'  -fn 'Terminus-12' &
#dmenu_launch &
